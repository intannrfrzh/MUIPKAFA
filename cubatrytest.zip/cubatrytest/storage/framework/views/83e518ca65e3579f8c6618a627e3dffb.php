<!DOCTYPE html>

<html lang="en">

<head>
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    /* Global styles */
    body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        /* Main layout styles */
        .main-layout {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        /* Content styles */
        .content {
            flex: 1;
            background-color: #fff;
            padding: 20px;
            overflow-y: auto;
        }

        /* Search bar styles */
    .search-bar {
        background-color: #f1f1f1;
        border-radius: 20px;
        padding: 5px 10px;
        display: flex;
        align-items: center;
        width: 250px;
    }

    .search-bar input[type="text"] {
        border: none;
        outline: none;
        padding: 5px;
        font-size: 16px;
        width: 200px;
    }

    .search-bar button {
        background-color: transparent;
        border: none;
        outline: none;
        cursor: pointer;
    }

    .addconbar{
    position: fixed; /* Fixed positioning to keep it at the right side */
    right: 0; /* Position it at the right side */
    height: 100vh; /* Set the height to full viewport height */
    width: 180px;
    background-color: #fff; 
    box-sizing: border-box;
    border-left: 1px solid #89c0ef;
    padding: 10px; /* Added padding for content */
    display: flex; /* Use flexbox for alignment */
    flex-direction: column; /* Stack items vertically */
    align-items: center; /* Center items horizontally */
    justify-content: flex-start; /* Align items to the start (top) of the container */
}

</style>
</head>

<body>
    
<?php echo $__env->make('partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
    
    <div class="main-layout">
        
            
            <div class="content">
            <?php if(Route::has('login')): ?>
                            <nav class="-mx-3 flex flex-1 justify-end">
                                <?php if(auth()->guard()->check()): ?>
                                    
                                <?php else: ?>
                                    <a
                                        href="<?php echo e(route('login')); ?>"
                                        class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                                    >
                                        Log in
                                    </a>

                                    <?php if(Route::has('register')): ?>
                                        <a
                                            href="<?php echo e(route('register')); ?>"
                                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                                        >
                                            Register
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </nav>
                        <?php endif; ?>
        </div>
            
        </div>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\cubatrytest\resources\views/tempt/home.blade.php ENDPATH**/ ?>