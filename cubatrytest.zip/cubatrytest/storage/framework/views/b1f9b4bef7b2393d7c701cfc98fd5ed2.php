<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    /* Global styles */
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        display: flex;
        flex-direction: column;
        height: 100vh;
    }

    /* Main layout styles */
    .main-layout {
        display: flex;
        flex: 1;
        overflow: hidden;
    }

    /* Content styles */
    .content {
        flex: 1;
        background-color: #fff;
        padding: 20px;
        overflow-y: auto;
    }

    /* General Styles */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
        color: #333;
    }

    .container {
        margin: 20px;
    }

    h1 {
        font-size: 24px;
        margin-bottom: 20px;
    }

    /* Sidebar */
    .sidebar {
        width: 200px;
        position: fixed;
        height: 100%;
        background: #394264;
        padding: 20px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar img {
        width: 150px;
        margin-bottom: 20px;
    }

    .sidebar a {
        color: #ffffff;
        display: block;
        margin: 10px 0;
        text-decoration: none;
        padding: 10px;
        border-radius: 5px;
        transition: background 0.3s;
    }

    .sidebar a:hover {
        background: #4b537d;
    }

    /* Content */
    .content {
        margin-left: 220px;
        padding: 20px;
    }

    /* Button Styles */
    .btn {
        display: inline-block;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        user-select: none;
        border: 1px solid transparent;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        line-height: 1.5;
        border-radius: 0.25rem;
        transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    .btn-primary {
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
    }

    .btn-primary:hover {
        color: #fff;
        background-color: #0056b3;
        border-color: #004085;
    }

    .btn-warning {
        color: #212529;
        background-color: #ffc107;
        border-color: #ffc107;
    }

    .btn-warning:hover {
        color: #212529;
        background-color: #e0a800;
        border-color: #d39e00;
    }

    .btn-danger {
        color: #fff;
        background-color: #dc3545;
        border-color: #dc3545;
    }

    .btn-danger:hover {
        color: #fff;
        background-color: #c82333;
        border-color: #bd2130;
    }

    /* Table Styles */
    .table {
        width: 100%;
        margin-bottom: 1rem;
        color: #212529;
        border-collapse: collapse;
    }

    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
    }

    .table tbody + tbody {
        border-top: 2px solid #dee2e6;
    }

    /* Status Styles */
    .status {
        font-weight: bold;
        padding: 5px 10px;
        border-radius: 5px;
    }

    .status.pending {
        background-color: #ffc107;
        color: #212529;
    }

    .status.rejected {
        background-color: #dc3545;
        color: #fff;
    }

    .status.approved {
        background-color: #28a745;
        color: #fff;
    }

    /* Popup styles */
    .popup {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 50, 0.9);
        padding: 20px;
        border-radius: 10px;
        text-align: center;
        color: white;
        z-index: 1000;
    }

    .popup button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        margin: 5px;
        cursor: pointer;
        border-radius: 5px;
    }

    .popup button:hover {
        background-color: #0056b3;
    }

    /* Overlay styles */
    .overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999;
    }

    /* Button styles */
    .deleteActivities {
        background-color: #e74c3c;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 5px;
        cursor: pointer;
    }

    .deleteActivities:hover {
        background-color: #c0392b;
    }

</style>
</head>

<body>
    
    <?php echo $__env->make('partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="main-layout">
        
        <?php echo $__env->make('partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        

        
        <div class="content">
            <div class="container">
                <h1>MANAGE ACTIVITIES</h1>
                <h2>Pending Approval</h2>
                <a href="<?php echo e(route('create')); ?>" class="btn btn-primary">ADD ACTIVITY </a>
                <table class="table mt-4">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Purpose</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($activity->A_Activity_name); ?></td>
                            <td><?php echo e($activity->A_Activity_details); ?></td>
                            <td><?php echo e($activity->A_Activity_datestart); ?></td>
                            <td><?php echo e($activity->A_Activity_dateend); ?></td>
                            <td><?php echo e($activity->A_Activity_timestart); ?></td>
                            <td><?php echo e($activity->A_Activity_timeend); ?></td>
                            <td><!--<?php echo e($activity->A_Activity_status); ?>-->
                                <span class="status <?php echo e(strtolower($activity->A_Activity_status)); ?>">
                                    <?php echo e(ucfirst($activity->A_Activity_status)); ?>

                                </span>
                            </td>
                            <td>
                            <a href="<?php echo e(route('show', $activity->id)); ?>" class="btn btn-info">VIEW</a>
                                <a href="<?php echo e(route('editActivities', $activity->id)); ?>" class="btn btn-warning">EDIT</a>
                                
                                <button class="deleteActivities" data-id="<?php echo e($activity->id); ?>" onclick="showDeletePopup(this)">DELETE</button>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <h2>Approved Activities</h2>
                <table class="table mt-4">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Purpose</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $approvedActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($activity->A_Activity_name); ?></td>
                            <td><?php echo e($activity->A_Activity_details); ?></td>
                            <td><?php echo e($activity->A_Activity_datestart); ?></td>
                            <td><?php echo e($activity->A_Activity_dateend); ?></td>
                            <td><?php echo e($activity->A_Activity_timestart); ?></td>
                            <td><?php echo e($activity->A_Activity_timeend); ?></td>
                            <td>
                            <span class="status approved">
                                    <?php echo e(ucfirst($activity->A_Activity_status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('show', $activity->id)); ?>" class="btn btn-info">VIEW</a>
                                <button class="deleteActivities" data-id="<?php echo e($activity->id); ?>" onclick="showDeletePopup(this)">DELETE</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <h2>Rejected Activities</h2>
                <table class="table mt-4">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Purpose</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rejectedActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($activity->A_Activity_name); ?></td>
                            <td><?php echo e($activity->A_Activity_details); ?></td>
                            <td><?php echo e($activity->A_Activity_datestart); ?></td>
                            <td><?php echo e($activity->A_Activity_dateend); ?></td>
                            <td><?php echo e($activity->A_Activity_timestart); ?></td>
                            <td><?php echo e($activity->A_Activity_timeend); ?></td>
                            <td>
                                <span class="status rejected">
                                    <?php echo e(ucfirst($activity->A_Activity_status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('show', $activity->id)); ?>" class="btn btn-info">VIEW</a>
                                <form action="<?php echo e(route('destroy', $activity->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">DELETE</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    
    <div class="overlay" id="overlay"></div>
    <div class="popup" id="deletePopup">
        <p>Delete the selected activity?</p>
            <button type="button" onclick="confirmDelete()">Confirm</button>
            <button type="button" onclick="closeDeletePopup()">Cancel</button>
        </form>
    </div>

    
    <div class="overlay" id="overlay"></div>
    <div class="popup" id="deletePopup">
        <p>Delete the selected activity?</p>
        <button type="button" onclick="confirmDelete()">Confirm</button>
        <button type="button" onclick="closeDeletePopup()">Cancel</button>
    </div>

    <script>
        let deleteActivityId = null;

        function showDeletePopup(button) {
            const activityId = button.getAttribute('data-id');
            deleteActivityId = activityId;
            document.getElementById('deletePopup').style.display = 'block';
            document.getElementById('overlay').style.display = 'block';
}

        function closeDeletePopup() {
            document.getElementById('deletePopup').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        }

        function confirmDelete() {
            if (deleteActivityId) {
                document.getElementById(`deleteForm${deleteActivityId}`).submit();
            }
        }
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\cubatrytest\resources\views/KAFAactivities/listActivitiesAdmin.blade.php ENDPATH**/ ?>