<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        /* Global styles */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        /* Main layout styles */
        .main-layout {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        /* Content styles */
        .content {
            flex: 1;
            background-color: #fff;
            padding: 20px;
            overflow-y: auto;
        }

        /* Search bar styles */
        .search-bar {
            background-color: #f1f1f1;
            border-radius: 20px;
            padding: 5px 10px;
            display: flex;
            align-items: center;
            width: 250px;
        }

        .search-bar input[type="text"] {
            border: none;
            outline: none;
            padding: 5px;
            font-size: 16px;
            width: 200px;
        }

        .search-bar button {
            background-color: transparent;
            border: none;
            outline: none;
            cursor: pointer;
        }

        .addconbar {
            position: fixed;
            right: 0;
            height: 100vh;
            width: 180px;
            background-color: #fff;
            box-sizing: border-box;
            border-left: 1px solid #89c0ef;
            padding: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
        }
    </style>
</head>

<body>
    
    <?php echo $__env->make('partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="main-layout">
        
        <?php echo $__env->make('partial.sidebar_student', ['User_ID' => $User_ID], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div class="content">
            <h1>STUDENT RESULT</h1>
            <hr>
            <p>STUDENT NAME: <?php echo e($student->SR_Student_Name); ?></p>
            <p>STUDENT ID: <?php echo e($student->User_ID); ?></p>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>CODE</th>
                        <th>SUBJECT NAME</th>
                        <th>GRADE</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($result->S_Subject_ID); ?></td>
                        <td><?php echo e($result->subject->S_Subject_name); ?></td>
                        <td><?php echo e($result->R_Result_grade); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Print Button -->
            <button onclick="window.print()" 
            style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Print Result</button>
        </div>
        
    </div>
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\cubatrytest\resources\views/manageStudentResult/student/viewresult_std.blade.php ENDPATH**/ ?>